// Initializes Firebase clients (Firestore and Realtime Database) for modular SDK
import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { getDatabase } from 'firebase/database';
import { firebaseConfig } from '../firebaseConfig';

const app = initializeApp(firebaseConfig);

export const firestore = getFirestore(app);
export const rtdb = getDatabase(app);
export default app;
