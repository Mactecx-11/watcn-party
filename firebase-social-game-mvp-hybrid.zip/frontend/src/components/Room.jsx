import React, { useEffect, useRef, useState } from 'react';
import { getAuth, signOut } from 'firebase/auth';
import { firestore, rtdb } from '../utils/firebaseInit';
import { collection, addDoc, serverTimestamp, query, orderBy, onSnapshot, doc, setDoc, getDoc } from 'firebase/firestore';
import { ref, onDisconnect, set as rset } from 'firebase/database';
import WatchSync from './WatchSync.jsx';

export default function Room({ user }){
  const [roomId, setRoomId] = useState('global-room');
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState('');
  const chatBoxRef = useRef();

  useEffect(()=>{
    // join presence in RTDB
    const presRef = ref(rtdb, `presence/${user.uid}`);
    rset(presRef, { online: true, name: user.displayName, lastActive: Date.now() })
      .catch(console.error);
    onDisconnect(presRef).remove();

    // listen to chat (Firestore)
    const msgsRef = collection(firestore, 'rooms', roomId, 'messages');
    const q = query(msgsRef, orderBy('timestamp', 'asc'));
    const unsub = onSnapshot(q, snapshot => {
      const data = [];
      snapshot.forEach(doc => data.push({ id: doc.id, ...doc.data() }));
      setMessages(data);
      setTimeout(()=>{ chatBoxRef.current && (chatBoxRef.current.scrollTop = chatBoxRef.current.scrollHeight); }, 50);
    }, err => console.error('msg listen err', err));

    return ()=> unsub();
  }, [roomId, user.uid, user.displayName]);

  async function send(){
    if(!text) return;
    const msgsRef = collection(firestore, 'rooms', roomId, 'messages');
    await addDoc(msgsRef, { senderId: user.uid, senderName: user.displayName, text, timestamp: serverTimestamp() });
    setText('');
  }

  async function leave(){
    try{
      const auth = getAuth();
      await signOut(auth);
    }catch(e){ console.error(e); }
  }

  return (
    <div className="container">
      <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
        <h3>Room: {roomId}</h3>
        <div>
          <button onClick={() => setRoomId(prompt('Enter room id', roomId) || roomId)}>Change Room</button>
          <button onClick={leave} style={{marginLeft:8}}>Sign out</button>
        </div>
      </div>

      <div className="room-grid" style={{marginTop:12}}>
        <div>
          <WatchSync roomId={roomId} user={user} firestore={firestore} />
          <div style={{marginTop:12}}>
            <div ref={chatBoxRef} className="chat-box">
              {messages.map(m => <div key={m.id} className="message"><b>{m.senderName}</b>: {m.text}</div>)}
            </div>
            <div style={{marginTop:8}}>
              <input value={text} onChange={e=>setText(e.target.value)} placeholder="Type a message" style={{width:'70%'}} />
              <button onClick={send} style={{marginLeft:8}}>Send</button>
            </div>
          </div>
        </div>

        <div style={{border:'1px solid #eee', padding:8}}>
          <h4>Nearby & Presence (Realtime DB)</h4>
          <p>Presence is stored in Realtime Database at <code>/presence/{'{userId}'}</code>.</p>
          <p>Implement a presence list or map query later.</p>
        </div>
      </div>
    </div>
  );
}
