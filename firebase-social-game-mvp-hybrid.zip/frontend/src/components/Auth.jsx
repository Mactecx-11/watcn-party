import React from 'react';
import { getAuth, GoogleAuthProvider, signInWithPopup } from 'firebase/auth';

export default function Auth(){
  async function signIn(){
    try{
      const auth = getAuth();
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
    }catch(err){
      console.error('Sign in error', err);
      alert('Sign in failed: ' + err.message);
    }
  }

  return (
    <div className="container">
      <h2>Sign in</h2>
      <button onClick={signIn}>Sign in with Google</button>
      <p>Make sure you added <code>localhost</code> and your hosting domain to Firebase Authorized Domains.</p>
    </div>
  );
}
