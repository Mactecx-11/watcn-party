import React, { useEffect, useRef, useState } from 'react';
import { doc, setDoc, onSnapshot, getDoc, updateDoc } from 'firebase/firestore';
import { serverTimestamp } from 'firebase/firestore';

export default function WatchSync({ roomId, user, firestore }){
  const playerRef = useRef(null);
  const [isHost, setIsHost] = useState(false);
  const [state, setState] = useState({ videoId: 'dQw4w9WgXcQ', isPlaying: false, currentTime: 0, hostId: null });

  useEffect(()=>{
    // setup YouTube script
    const tag = document.createElement('script');
    tag.src = 'https://www.youtube.com/iframe_api';
    document.body.appendChild(tag);

    window.onYouTubeIframeAPIReady = () => {
      playerRef.current = new window.YT.Player('yt-player', {
        height: '320',
        width: '560',
        videoId: state.videoId,
        events: {
          onStateChange: e => {
            // host emits - update Firestore
            if(!isHost) return;
            const playing = e.data === window.YT.PlayerState.PLAYING;
            const currentTime = playerRef.current.getCurrentTime();
            const roomDoc = doc(firestore, 'rooms', roomId);
            updateDoc(roomDoc, { isPlaying: playing, currentTime, lastUpdated: serverTimestamp() }).catch(err=>{});
          }
        }
      });
    };

    // Firestore listener for room video state
    const roomDoc = doc(firestore, 'rooms', roomId);
    const unsub = onSnapshot(roomDoc, snap => {
      if(!snap.exists()) return;
      const d = snap.data();
      setState(d);
      if(playerRef.current && typeof d.isPlaying === 'boolean'){
        try{
          if(d.isPlaying){
            playerRef.current.seekTo(d.currentTime || 0, true);
            playerRef.current.playVideo();
          } else {
            playerRef.current.pauseVideo();
            playerRef.current.seekTo(d.currentTime || 0, true);
          }
        }catch(e){}
      }
      setIsHost(d.hostId === user.uid);
    }, err => {});

    // ensure room doc exists (create if not)
    (async () => {
      const s = await getDoc(roomDoc);
      if(!s.exists()){
        await setDoc(roomDoc, { hostId: user.uid, videoId: state.videoId, isPlaying: false, currentTime: 0, lastUpdated: serverTimestamp() });
        setIsHost(true);
      }
    })();

    return () => unsub();
  }, [roomId, user.uid, user.displayName]);

  return (
    <div>
      <div id="yt-player"></div>
      <p style={{fontSize:13, color:'#666'}}>Host: {isHost ? 'Yes' : 'No'} — Video ID: {state.videoId}</p>
    </div>
  );
}
