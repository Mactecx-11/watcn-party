import React, { useEffect, useState } from 'react';
import { initializeApp } from 'firebase/app';
import { getAuth, onAuthStateChanged } from 'firebase/auth';
import { firebaseConfig } from './firebaseConfig';
import Auth from './components/Auth.jsx';
import Room from './components/Room.jsx';
import './utils/firebaseInit.js';

initializeApp(firebaseConfig);

export default function App(){
  const [user, setUser] = useState(null);

  useEffect(()=>{
    const auth = getAuth();
    const unsub = onAuthStateChanged(auth, u => setUser(u));
    return () => unsub();
  },[]);

  if(!user) return <Auth />;
  return <Room user={user} />;
}
